<?php require("layout/header.php"); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12" style="margin:50px 0;">
            <div class="photo-area">
                <img src="img/mahperiHatun.jpg" alt="">
            </div>
            <hr>
            <div class="text-area">
                <h4>MAHPERİ HATUN KERVANSARAYI</h4>
                Mahperi Hatun (Pazar) Kervansarayı, Tokat-Pazar yolunun 29'uncu kilometresinde Pazar İlçesi'ne yaklaşık 1 kilometre mesafede, yolun güneydoğusundaki kuzeybatıya meyilli bir araziye inşa edilmiştir. Avlu ve kapalı kısım portallerindeki dörder satırlık sülüs hatlı kitabelerine göre, 1238 yılında Alaeddin Keykubâd’ın zevcesi ve II.Gıyaseddin Keyhüsrev’in validesi Mahperi Hatun tarafından yaptırılmıştır.
            </div>
            <hr>
        </div>
    </div>
</div>
<?php require("layout/footer.php"); ?>