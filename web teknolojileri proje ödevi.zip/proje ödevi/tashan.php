<?php require("layout/header.php"); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12" style="margin:50px 0;">
            <div class="photo-area">
                <img src="img/tashan.jpeg" alt="">
            </div>
            <hr>
            <div class="text-area">
                <h4>TAŞHAN</h4>
                Türkiye’nin en güzel hanlarından biri olan Taşhan, Anadolu’daki en büyük şehir hanlarındandır. Gaziosmanpaşa Bulvarı üzerindedir. 1626-1632 yılları arasında inşa edilmiş bir Osmanlı eseridir. Dikdörtgen planlı, açık avlulu, iki katlı bir yapıdır. İçeride dış dükkanların bulunduğu kuzey ve doğu yönünde revaksız işyerleri, güney ve batı yönünde ise önünde revak bulunan dükkanlar yer almaktadır. Giriş koridorunun sonunda sağdan ve soldan ikinci kata çıkılmaktadır. İkinci katta bütün odalar revaka açılmaktadır. Girişin üstünde kubbeli bir mekan vardır ve bu mekan konsollar üzerinde dışa taşmaktadır. Odalarda dışa açılan birer pencere, bir ocak ve niş bulunmaktadır. İçte 76 dışta toplam 103 mekan vardır. Anadolu’daki en büyük şehir hanlarındandır.
            </div>
            <hr>
        </div>
    </div>
</div>
<?php require("layout/footer.php"); ?>