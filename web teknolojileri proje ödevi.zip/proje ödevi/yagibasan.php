<?php require("layout/header.php"); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12" style="margin:50px 0;">
            <div class="photo-area">
                <img src="img/yagibasan.jpg" alt="">
            </div>
            <hr>
            <div class="text-area">
                <h4>YAĞIBASAN MEDRESESİ</h4>
                Yağıbasan Medresesi, Danişment Beyliği’nden Nizamettin Yağıbasan’ın Tokat ve Niksar’da yaptırdığı iki medresedir. Tokat bulunan Yağıbasan medresesi Çukur Medrese olarak da bilinir.
                1151 ve1152 yıllarında yaptırılan medrese, kapalı avlulu Anadolu medreselerinin ilk örneklerinden biri olması açısından önemlidir. Avluyu örten 14 metre çapındaki kubbenin ortası açıktır. Yanlarda küçüklü, büyüklü tonozlu odalar, giriş eyvanının karşısında mescit ve dershane işlevindeki ana eyvan yer alır.
                Niksar’da bulunan Yağıbasan Medresesi (1157/1158) ise Tokat’taki medrese gibi kapalı avlulu medreseler planında ve yaklaşık 11 metre çapında bir kubbeyle örtülüdür. Bir bölümü Niksar Kalesi’ nin duvarlarına yaslanan medresenin doğu ve kuzeyinde iki eyvan, batısında beşik tonozlu küçük mekânlar vardır. Her iki medrese de yalın, süslemesiz örneklerdir.

            </div>
            <hr>
        </div>
    </div>
</div>
<?php require("layout/footer.php"); ?>